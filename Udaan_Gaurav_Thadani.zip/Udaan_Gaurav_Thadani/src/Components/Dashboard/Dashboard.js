import '../Styles/Dashboard.css';
import WrapperHOC  from '../../HOC/WrapperHOC';
import { useState ,useRef } from 'react';
function App() {
let[hour,setHour]=useState("00");
let[minute,setMinute]=useState("00");
let[second,setSec]=useState("00"); 
const [timer,setTimeFnc]= useState(0)
const inputRef=useRef();

const handleTimer=()=>{
    second = parseInt(second)+1;
    setSec(second);
    if(second == 60)
    {
      minute=parseInt(minute)+1;
      setMinute(minute);
      second=0;
      // setSec(0);
    }
    if(minute == 60)
    {
      hour = hour + 1;
      setHour(hour);
      setMinute(0);
      setSec(0);
    }
    if(second<10)
    {
      setSec('0'+second);
    }
}
const handleTimerClock=()=>{
  // debugger;
  setTimeFnc(1);
  var Timer__Array=inputRef.current.outerText.split(":");
  setHour(parseInt(Timer__Array[0]));
  setMinute(parseInt(Timer__Array[1]));
  setSec(parseInt(Timer__Array[2]));
   setInterval(()=>{
     handleTimer();
   },1000)
}


const initialVal=()=>{
  setSec("00");
  setMinute("00");
  setHour("00");
}
const handleStopClock=()=>{
  setTimeFnc(0);
  alert(`${hour}:${minute}:${second}`);
  initialVal();
}

  return (
    <div className="App">
      <div className="card_container">
     <div className="Input_field_div">
      <input placeholder="What are you working on?" className="input__text"/>
      <h1 id="timer_id" ref={inputRef}>{`${hour}:${minute}:${second}`}</h1>
      {timer==1?<button onClick={handleStopClock} className="start__level">
        STOP
      </button> : <button onClick={handleTimerClock} className="start__level">
        START
      </button>}
     </div>
     </div>
    </div>
  );
}

export default WrapperHOC(App);
